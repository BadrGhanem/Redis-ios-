
#import "ViewController.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include "hiredis.h"
#include "async.h"


@interface ViewController (){
    
    redisReply *reply;
}

@end

@implementation ViewController



- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    struct timeval timeout = { 1, 500000 }; // 1.5 seconds

    redisContext *c = redisConnectWithTimeout("domainorip.com", 17953, timeout);

    if (c == NULL || c->err) {
        if (c) {
            printf("Connection error: %s\n", c->errstr);
            redisFree(c);
        } else {
            printf("Connection error: can't allocate redis context\n");
        }
    }

    
    /* AUTH */
    reply = redisCommand(c,"AUTH %s", "mypassword");
    printf("AUTH: %s\n", reply->str);
    freeReplyObject(reply);
    
    
 
/*
    EX seconds -- Set the specified expire time, in seconds.
    PX milliseconds -- Set the specified expire time, in milliseconds.
    NX -- Only set the key if it does not already exist.
    XX -- Only set the key if it already exist.
 
*/
    
    reply = redisCommand(c, "SET user1 login EX 10");
    
    freeReplyObject(reply);
    
    
    reply = redisCommand(c, "SET user5 logout EX 5");
 
    freeReplyObject(reply);
    
   
    reply = redisCommand(c, "KEYS *");


    if (reply->type == REDIS_REPLY_ARRAY && reply != NULL) {
        
    for (int j = 0; j < reply->elements; j++) {
        
        redisReply *value = redisCommand(c, "GET %s", reply->element[j]->str);
        
        printf("%u)  %s:%s\n", j, reply->element[j]->str, value->str);
        
        freeReplyObject(value);

        
    }
        
    
  }

  freeReplyObject(reply);


    /* Disconnects and frees the context */
    redisFree(c);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
